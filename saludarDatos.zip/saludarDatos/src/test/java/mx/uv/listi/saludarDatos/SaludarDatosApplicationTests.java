package mx.uv.listi.saludarDatos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaludarDatosApplicationTests {

	@Test
	void contextLoads() {
	}

}
