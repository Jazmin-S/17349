package mx.uv.listi.saludarDatos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaludarDatosApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaludarDatosApplication.class, args);
	}

}
